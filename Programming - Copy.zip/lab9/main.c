#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Shop{
   char shopName[20];
   char phoneNumber[25];
};

union Size{
    int digit;
char letter;
char word[20];
};

struct Clothing{
int code;
int year;
struct Shop shop;

struct Price {
char currency[10];
float clothesAmount;
}price;

union Size size;

int sizeType;
};

struct Shop allShops[5];
struct Clothing allClothes[10];

int shopCount = 0, clothesCount = 0;

void showShops();
void showDetails(int);
void showClothes(int);
void addClothing();
int main()
{
    struct Shop shop1 = {"Vanessa's clothing", "4567809979"};//
    struct Shop shop2 = {"Jason's Closet", "456789734"};
     allShops[0] = shop1;
     allShops[1] = shop2;
     shopCount = 2;
   // printf("Name: %s\nPhoneNumber: %s\n", shops[0].shopName,shops[0].phoneNumber);
   struct Clothing clothes1 = {01,2022,{"Vanessa's clothing", "4567809979"}, {"GHS", 5000}, .size.letter = 'M', 2};
   struct Clothing clothes2 = {02,2023,{"Vanessa's clothing", "4567809979"}, {"GHS", 10000}, .size.word = "medium", 3};
   struct Clothing clothes3 = {03,2022,{"Jason's Closet", "456789734"}, {"$", 500}, .size.digit = 25, 1};
   struct Clothing clothes4 = {04,2020,{"Jason's Closet", "456789734"}, {"�", 50}, .size.letter = 'M', 2};
   allClothes[0] = clothes1;
   allClothes[1] = clothes2;
   allClothes[2] = clothes3;
   allClothes[3] = clothes4;
   clothesCount = 4;
    //printf("clothing :%s\n", clothes1.shop.shopName);
   int looping=0;

 do{
 printf("CLOTHING MALL\n1.Visit Shop\t2.Add Clothing\t3.Exit\n");
 int option;
 scanf(" %d", &looping);
 switch(looping){
 case 1: showShops();
 scanf(" %d", &option);
 showDetails(option-1);
 showClothes(option-1);
 break;
 case 2: addClothing();
        break;
 case 3: looping = 0;
 printf("Thanks for shopping :)");
 break;
 default:
     printf("Invalid choice\n");
     break;
 }
 }while(looping>0);

   //printf("SizeType:%s\n", clothes1.price.currency);
    return 0;
}

void showShops()
{
    for(int i = 0; i < shopCount; i++){
        printf("%d - Shop %d\n", i+1, i+1);
    }
}
void showDetails(int options)
{
        printf("Shop Name: %s\nPhone Number: %s\n\n", allShops[options].shopName, allShops[options].phoneNumber);
}

void showClothes(int options)
{
    for(int i = 0; i < clothesCount; i++){
        if(!strcmp(allShops[options].shopName, allClothes[i].shop.shopName))
        {
           printf("Code: %d\nYear: %d\nShop Name: %s\nPhone Number: %s2\n", allClothes[i].code, allClothes[i].year, allClothes[i].shop.shopName, allClothes[i].shop.phoneNumber);

           if(allClothes[i].sizeType == 1)
                printf("Size: %d\n\n",allClothes[i].size.digit);
           else if (allClothes[i].sizeType == 2)
                printf("Size: %c\n\n",allClothes[i].size.letter);
           else if(allClothes[i].sizeType == 3)
                printf("Size: %s\n\n",allClothes[i].size.word);
            else
                printf("No size\n\n");
        }
    }
}


void addClothing()
{
    printf("You can start adding new clothes to the shops\n");
    printf("You can either add clothes to existing shops or create new shops\n");
    struct Shop userShop;
    fflush(stdin);
    gets(userShop.shopName);
    printf("How many clothes do you want to add:");
    int clothesNumber;
    scanf(" %d", &clothesNumber);
    for(int i = 0; i < clothesNumber; i++){
    if(!strcmp(userShop.shopName, "Shop 1"))
    {
        strcpy(userShop.shopName, allShops[0].shopName);
        strcpy(userShop.phoneNumber, allShops[0].phoneNumber);
        //userShop.phoneNumber = allShops[0].phoneNumber;
        printf("Shop Name: %s\nPhone Number: %s\n\n", userShop.shopName, userShop.phoneNumber);

    } else if(!strcmp(userShop.shopName, "Shop 2"))
    {
        strcpy(userShop.shopName, allShops[1].shopName);
        strcpy(userShop.phoneNumber, allShops[1].phoneNumber);
        //userShop.phoneNumber = allShops[0].phoneNumber;
        printf("Shop Name: %s\nPhone Number: %s\n\n", userShop.shopName, userShop.phoneNumber);

    }else
    { fflush(stdin);
        printf("\nEnter the shop's Name:");
        gets(userShop.shopName);
        fflush(stdin);
        printf("\nEnter the shop Owner,s number:");
        gets(userShop.phoneNumber);
        allShops[i + 2] = userShop;
        shopCount++;
    }
    struct Clothing userClothes;
    printf("\nEnter the code of the clothes:");
    scanf(" %d", &userClothes.code);
    printf("\nEnter the year of the clothes:");
    scanf(" %d", &userClothes.year);

    strcpy(userClothes.shop.shopName, userShop.shopName);
    strcpy(userClothes.shop.phoneNumber, userShop.phoneNumber);

    printf("\nEnter the currency of the clothes:");
    fflush(stdin);
    gets(userClothes.price.currency);
    printf("\nEnter the cost of the clothes:");
    fflush(stdin);
    scanf(" %f", &userClothes.price.clothesAmount);
    printf("\nWhat would you like to denote the clothes size with?\n1 - digit\n2 - letter\n3 - word\n");
    int choice;
    fflush(stdin);
    scanf("%d", &choice);
    if (choice == 1){
        printf("\nEnter the size of the clothes in digit\n");
        scanf(" %d", &userClothes.size.digit);
        userClothes.sizeType = 1;
    }
    else if(choice == 2){
        printf("\nEnter the size of the clothes in letter\n");
        scanf(" %c", &userClothes.size.letter);
        userClothes.sizeType = 2;
    }
    else if(choice == 3){
        printf("\nEnter the size of the clothes in words\n");
        scanf(" %s", userClothes.size.word);
        userClothes.sizeType = 3;
    }
    allClothes[i + 2] = userClothes;
}}
