#include <stdio.h>
#include <stdlib.h>

float balance = 600000;
int authenticate(int);
int requestAmount();
void deposit();
void transfer();
void withDraw();

int main(){
 start:
 printf("WELCOME TO ABC BANK\nEnter your four digit pin\n");
 int tries = 0;
 int pin=0;
 scanf("%d", &pin);
 menu:
 if(authenticate(pin) && tries < 4){
 int menu_item;
 printf("Select an option\n1. Check Balance\n2. Withdrawal\n3. Deposit\n4. Transfer\n");
 scanf("%d", &menu_item);
 switch(menu_item){
 case 1: printf("%g\n", balance);
 break;
 case 2: withDraw(requestAmount());
 break;
 case 3: deposit(requestAmount());
 break;
 case 4: transfer(requestAmount());
 }
 }
 else{
 ++tries;
 printf("Invalid pin after %d tries\n", tries);
 goto start;
 }
 int response;
 printf("Would you like to perform another transaction?\n1. Yes\n2. No\n");
 scanf("%d", &response);
 if(response == 1){goto menu;}

printf("Thank you for banking with us\n");
return 0;
}
int authenticate(int pin)
{
    int userPin = 12345;
    if (userPin == pin)
    {
        printf("Login successful\n");
        return 1;
    }
    else
    {
        printf("Login unsuccessful\n");
        return 0;
    }
}

int requestAmount(){
int amount = 0;
printf("Please enter amount for transaction:");
scanf("%d", &amount);
return amount;
}

void deposit( int amount)
{
    balance += amount;
    printf("Your new balance is %.2f\n", balance);
}
void withDraw(int amount)
{
   balance -= amount;
   printf("Your new balance is %.2f\n", balance);
}
void transfer(int amount)
{
    int recipientsAccountNum = 0;
    printf("Please enter the recipients account number:");
    scanf("%d", &recipientsAccountNum);
    balance -= amount;
    printf("%d sent to account number %d\nYour new balance is %.2f", amount, recipientsAccountNum, balance);
}

