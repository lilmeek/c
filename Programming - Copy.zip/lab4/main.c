#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main()
{
    int order = 0, time = 0;
    float cost = 0.0;
    printf("\"WELCOME TO FIIFI'S ICE CREAM SHOP\nWhat would you like to order\?\"\n");
    do{
        int flavour = 0, toppings = 0, size = 0;
        printf("1 - Vanilla\n2 - Strawberry\n3 - Chocolate\n4 - Mango\n5 - Enquiries\n");
        scanf("%d", &flavour);
        //fflush(stdin);
        if (flavour < 5 && flavour != 0)
        {
            printf("1 - small\n2 - LARGE\n");
            scanf("%d", &size);
        }


        switch (flavour)
        {
        case 1:
            if (size == 1){
                printf("You ordered small size and");
                cost += 5;
                time += 2;
            } else if (size == 2)
            {
              printf("You selected large size and");
                cost += 8;
                time += 3;
            }else
                printf("Invalid size entry\n");
            printf(" Vanilla flavoured ice cream\n");
            printf("Your total cost is now GHS%.2f and your waiting time will be %d\n", cost, time);
            break;
        case 2:
            if (size == 1){
                printf("You ordered small size and");
                cost += 5;
                time += 2;
            } else if (size == 2)
            {
              printf("You selected large size and");
                cost += 8;
                time += 3;
            }else
                printf("Invalid size entry\n");
            printf(" Strawberry flavoured ice cream\n");
            printf("Your total cost is now GHS%.2f and your waiting time will be %d\n", cost, time);
            break;
        case 3:
            if (size == 1){
                printf("You ordered small size and");
                cost += 6;
                time += 2;
            } else if (size == 2)
            {
              printf("You selected large size and");
                cost += 9;
                time += 3;
            } else
                printf("Invalid size entry\n");
            printf(" Chocolate flavoured ice cream\n");
            printf("Your total cost is now GHS%.2f and your waiting time will be %d\n", cost, time);
            break;
        case 4:
            if (size == 1){
                printf("You ordered small size and");
                cost += 7;
                time += 2;
            } else if (size == 2)
            {
              printf("You selected large size and");
                cost += 10;
                time += 3;
            }else
                printf("Invalid size entry\n");
            printf(" Mango flavoured ice cream\n");
            printf("Your total cost is now GHS%.2f and your waiting time will be %d\n", cost, time);
            break;
        case 5:
            printf("A customer service agent will be with you soon\n");
            break;
        default:
            printf("Invalid flavour entry\n");
        }
        //fflush(stdin);
if (flavour != 0 && flavour  < 5){
        do {
                printf("What Toppings would you like to add\?\n");
            printf("1 - Sprinkles\n2 - Whipped cream\n3 - Chopped Nuts\n4 - Coconuts Shavings\n5 - No Toppings\n");
            scanf("%d", &toppings);
        switch(toppings)
        {
        case 1:
            printf("You have selected Sprinkles toppings\n");
            cost += 2;
            time += 1;
            toppings++;
            printf("Your total cost is now GHS%.2f and your waiting time will be %d\n", cost, time);
            break;
        case 2:
            printf("You have selected Whipped cream toppings\n");
            cost += 3;
            time += 2;
            toppings++;
            printf("Your total cost is now GHS%.2f and your waiting time will be %d\n", cost, time);
            break;
        case 3:
            printf("You have selected Chopped Nuts toppings\n");
            cost += 4;
            time += 3;
            toppings++;
            printf("Your total cost is now GHS%.2f and your waiting time will be %d\n", cost, time);
            break;
        case 4:
            printf("You have selected Coconuts Shavings toppings\n");
            cost += 5;
            time += 4;
            toppings++;
            printf("Your total cost is now GHS%.2f and your waiting time will be %d\n", cost, time);
            break;
        case 5:
            toppings = 0;
            break;
        default:
            printf("Invalid toppings entry\n");
            break;
        }
        } while(toppings > 0);}
        printf("Would you like anything else\?\n1 - Yes\n2 - No\n");
        int choice;
        scanf("%d", &choice);

        if (choice == 1)
            order++;
        else{
            order = 0;
            printf("Your total cost is GHS%.2f and a waiting time of %d\n", cost, time);

    }
    } while( order > 0);
    printf("Kindly wait for your order\n");
    for ( int i = 60*time; i >= 0; i--)
    {
        printf("Time left:%d\n", i);
    }
    printf("\nHere is your order\nThanks for coming to Fiifi's Ice Cream\n");

    return 0;
}
