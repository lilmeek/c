#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

float *add(float *, float);
float *subtract(float *, float);
float *mult(float *, float);
float *divide(float *, float);

int main()
{
    /*int x =5;
    int *ptrx = &x;
    int **ptrptrx = &ptrx;*/
    // printf("x: %d\nptrx: %d\nptrptrx: %d", x, *ptrx, **ptrptrx);

    printf("This is a calculator program\n\nIt first takes the first operand\nFollowed by the operation you want to perform \nE.g,\n\t+ for addition\n\t- for subtraction\n\t* for multiplication\n\t/ for division\nThen it takes the second operand\n");
    printf("\nINSTRUCTIONS\n\n\tAfter every calculation, the result is stored as the first operand\n\tSo, additional operations can be done by entering the operator and second operand to work on the result\n");
    printf("\tTo reset the calculator, type @ when prompted to enter operator\n");
    printf("When you are done with all your calculation, type # when prompted to enter operator.\n");
    float operand1, operand2;
    float *result = &operand1;
    char operation;
    bool on = true;
start:
    printf("\nEnter first operand:");
    scanf("%f", &operand1);
    do{
        printf("\nEnter operator:");
        fflush(stdin);
        scanf("%c", &operation);
        if (operation != '@' && operation != '#')
        {
            printf("\nEnter second operand:");
            scanf("%f", &operand2);
            }

        switch(operation)
        {
        case '+':
           printf("Result = %.2f", *add(result, operand2));
            break;
        case '-':
            printf("Result = %.2f", *subtract(result, operand2));
            break;
        case '*':
            printf("Result = %.2f", *mult(result, operand2));
            break;
        case '/':
            printf("Result = %.2f", *divide(result, operand2));
            break;
        case '#':
             printf("Goodbye :(\n");
             on = false;
             break;
        case '@':
            printf("Calculator reset completed\n");
            goto start;
            break;
        default:
             printf("Error :(\n");
             goto start;
            }
    }while(on);
    return 0;
}

float *add(float *opr1, float opr2)
{
    printf("%.2f + %.2f\n", *opr1, opr2);
    *opr1 += opr2;
    return opr1;
}

float *subtract(float *opr1, float opr2)
{
    printf("%.2f - %.2f\n", *opr1, opr2);
    *opr1 -= opr2;
    return opr1;
}

float *mult(float *opr1, float opr2)
{
    printf("%.2f * %.2f\n", *opr1, opr2);
    *opr1 *= opr2;
    return opr1;
}

float *divide(float *opr1, float opr2)
{
    printf("%.2f / %.2f\n", *opr1, opr2);
    *opr1 /= opr2;
    return opr1;
    }
