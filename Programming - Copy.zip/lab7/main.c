#include <stdio.h>
#include <stdlib.h>
char grade(int);
int main()
{
   printf("Enter the number of students in the class\n");
   int length;
   scanf("%d", &length);
   float marks[length];
   printf("Start entering their marks");
   for (int i = 0; i < length; i++)
   {
       printf("\nStudent %d\t", i+1);
       scanf("%f", &marks[i]);
       //printf("\nStudent %d: %d\t", i+1, marks[i]);
   }
   float mean;
   for (int i = 0; i < length; i++)
   {
       printf("\nStudent %d: %.2f\t", i+1, marks[i]);
       mean += marks[i];
   }
   mean /= length;
   printf("\nmean mark of students is %.2f\n", mean);

    float temp = 0;
 for(int i; i<length; ++i){
 for(int j=i+1; j<length; ++j){
 if(marks[i] > marks[j]){
 //switch positions
 temp = marks[i];
 marks[i] = marks[j];
 marks[j] = temp;
 }
 }

}
for (int i = 0; i < length; i++)
   {
       printf("\nStudent %d: %.2f\t", i+1, marks[i]);

   }
   float studentResults[7][2] = { {3, 57.45}, {2, 69.29}, {2, 71.32}, {4, 65.05}, {3, 75.67}, {3, 48.65}, {1, 88.21}};

   printf("\nCREDIT\t|SCORE\t|GRADE\t|\n");
 printf("\t|\t|\t|\n");
 for(int i=0; i<7; ++i){
 for(int j=0; j<2; ++j){
 printf("%.2f \t|", studentResults[i][j]);
 if(j%2 == 1){
 printf("%c \t|", grade(studentResults[i][j]));
 printf("\n\t|\t|\t|");
 }
 }
 printf("\n");
 }
 float weightedsum = 0.0;
 float totalcredits = 0.0;

 for(int i=0; i<7; ++i){
 weightedsum = weightedsum + (studentResults[i][0] * studentResults[i][1]);
 totalcredits += studentResults[i][0];
 }
 float cwa = weightedsum/totalcredits;
 printf("\ncwa = %.2f\n", cwa);
return 0;
}
char grade(int score)
{
    if (score >= 70)
        return 'A';
    else if(score >= 60)
        return 'B';
    else if(score >= 50)
        return 'C';
    else if (score >= 40)
        return 'D';
    else
        return 'F';
}
