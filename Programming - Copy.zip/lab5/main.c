#include <stdio.h>
#include <stdlib.h>

float square(float);
float circle(float);
float triangle(float, float);
float rectangle(float, float);

int main()
{
    float area;
    printf("Shape 1\nIt contains a semi-circle and a rectangle.\n");
    area = circle(4)/2 + rectangle(12,8);
    printf("Area of shape 1 = %.2fft\n\n ", area);

    printf("Shape 2\nIt contains a triangle and a rectangle.\n");
    area = triangle(8, 19) + rectangle(13,8);
    printf("Area of shape 2 = %.2fft\n\n ", area);

    printf("Shape 3\nIt contains a square and a rectangle.\n");
    area = square(5) + rectangle(11,8);
    printf("Area of shape 3 = %.2fft\n\n ", area);

    printf("Shape 4\nIt contains a semi-circle and a triangle.\n");
    area = circle(4)/2 + triangle(8,7);
    printf("Area of shape 4 = %.2fft\n\n ", area);

    printf("Shape 5\nIt contains a square and a triangle.\n");
    area = square(5) + triangle(7,4);
    printf("Area of shape 5 = %.2fft\n\n ", area);

    printf("Shape 6\nIt contains a square and a rectangle.\n");
    area = square(6) + rectangle(12,6);
    printf("Area of shape 6 = %.2fft\n\n ", area);

    printf("FURTHER PRACTICE\n\n");
    printf("Shape 1\nIt contains a triangle, semi-cicle and a rectangle.\n");
    area = triangle(13, 12) + rectangle(13,12) + circle(9);
    printf("Area of shape 1 = %.2fft\n\n ", area);

    printf("Shape 2\nIt contains a triangle and a rectangle.\n");
    area = triangle(7,19) + rectangle(15,19);
    printf("Area of shape 2 = %.2fft\n\n ", area);

    printf("Shape 3\nIt contains a triangle and a circle.\n");
    area =  circle(6) - triangle(12,6) ;
    printf("Area of shape 3 = %.2fft\n\n ", area);

     printf("Shape 4\nIt contains a square and a parallelogram.\n");
    area =  square(11) + rectangle(11, 7);
    printf("Area of shape 4 = %.2fft\n\n ", area);

     printf("Shape 5\nIt contains a rectangle and a semi-circle.\n");
    area =  circle(11)/2 + rectangle(22, 13) ;
    printf("Area of shape 5 = %.2fft\n\n ", area);

     printf("Shape 6\nIt contains a triangle and a two rectangle.\n");
    area =  rectangle(17, 26) - triangle(14,17);
    printf("Area of shape 6 = %.2fft\n\n ", area);

    return 0;
}

float square(float len)
{
    return len * len;
}
float circle(float rad)
{
 return (3.14 * rad * rad);
}
float triangle(float base, float height)
{
    return (0.5 * base * height);
}
float rectangle(float length, float width)
{
    return (length * width);
}
