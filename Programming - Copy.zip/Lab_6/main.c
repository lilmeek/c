#include <stdio.h>
#include <stdlib.h>

int authenticate(int pin);
float requestAmount();
void deposit(float amount);
void withDraw(float amount);
void transfer(float amount);

float balance = 0.00;

int main(){
int tries = 0;

start:

printf("WELCOME TO ABC BANK\nEnter your four digit pin\n");
int pin=0;
scanf("%d", &pin);

menu:

if(authenticate(pin) && tries < 4){
int menu_item;
printf("Select an option\n1. Check Balance\n2. Withdrawal\n3. Deposit\n4. Transfer\n");
scanf("%d", &menu_item);
switch(menu_item){
case 1: printf("%g\n", balance);
break;
case 2: withDraw(requestAmount());
break;
case 3: deposit(requestAmount());
break;
case 4: transfer(requestAmount());
}

int response;
printf("Would you like to perform another transaction?\n1. Yes\n2.No\n");
scanf("%d", &response);
if(response == 1){goto menu;}
printf("Thank you for banking with us\n");
}else if(tries < 4){
++tries;
printf("%d", tries);
printf("Invalid pin after %d tries\n", tries);
goto start;
}
else
{
    printf("You have entered the wrong pin for 4 consecutive times\n"
           "Please seek assistance from the Customer Care Centre\n"
           "Thank You for banking with us");
}

return 0;
}
int authenticate(int pin)
{
    int user_pin = 12345;
    if (user_pin == pin)
        return 1;
    else
        return 0;
}

float requestAmount(){
printf("Please enter the amount for your transaction\n");
float amount = 0.00;
scanf("%f", &amount);
return amount;
}

void deposit(float amount)
{
    balance += amount;
    printf("Your new account balance is %.2f\n", balance);
}

void withDraw(float amount)
{
    balance -= amount;
    printf("Your remaining balance is %.2f\n", balance);
}

void transfer(float amount)
{
    printf("Please enter recipient\�s account number\n");
    int recNum = 0;
    scanf("%d", &recNum);
    balance -= amount;
    printf("%.2f sent to %d\nYour account balance is %.2f\n", amount, recNum, balance);
}


